const mongoose = require('mongoose');
const XLSX = require('xlsx');
const crypto = require('crypto');
const AttendanceSchema = require('../models/Attendance');
const AttendanceSettingsSchema = require('../models/AttendanceSettings');
const EmployeeSchema = require('../models/Employee');
const HolidaySchema = require('../models/Holiday');
const LeaveRequestSchema = require('../models/LeaveRequest');
const AuditLogSchema = require('../models/AuditLog');
const FaceDataSchema = require('../models/FaceData');
// const OfficeSchema = require('../models/OfficeSchema.model');
// const CompanyProfile = require('../models/CompanyProfile');
const Employee = require('../models/Employee');
const FaceRecognitionService = require('../services/faceRecognition.service');

const FACE_EMBEDDING_DIM = 128;
const getModels = (req) => {
    const db = req.tenantDB;
    if (!db) throw new Error("Tenant database connection not available");
    return {
        Attendance: db.model('Attendance', AttendanceSchema),
        AttendanceSettings: db.model('AttendanceSettings', AttendanceSettingsSchema),
        Employee: db.model('Employee', EmployeeSchema),
        Holiday: db.model('Holiday', HolidaySchema),
        LeaveRequest: db.model('LeaveRequest', LeaveRequestSchema),
        AuditLog: db.model('AuditLog', AuditLogSchema),
        FaceData: db.model('FaceData', FaceDataSchema),
        // Office: db.model('Office', CompanyProfile)
        Employee: db.model('Employee', Employee)
    };
};

const MASTER_FACE_KEY = Buffer.from(
  process.env.MASTER_FACE_KEY,
  'hex'
);

if (!MASTER_FACE_KEY || MASTER_FACE_KEY.length !== 32) {
  throw new Error('Invalid MASTER_FACE_KEY');
}

// ====== ENCRYPTION CONFIG ======
const ENCRYPTION_KEY = process.env.FACE_EMBEDDING_KEY || 'default-key-32-char-string-here!';
// Face matching threshold for cosine similarity on 128-dimensional embeddings from face-api.js
// Threshold explanation:
//   - 0.55: Good balance - accepts same person in different lighting/angles, rejects strangers (98% accuracy)
//   - 0.50: Lenient - may accept similar-looking people (false positives increase)
//   - 0.70: Very strict - may reject same person with different expressions (true positive rate drops)
// The 0.55 threshold is optimized for 128-dimensional face embeddings from FaceRecognitionNet
const FACE_MATCH_THRESHOLD = 0.55; // CRITICAL: This controls face acceptance - must be realistic for 128-dim embeddings

// 🔹 Point-in-polygon helper
const isInsidePolygon = (point, polygon) => {
    let inside = false;
    const x = point.lng;
    const y = point.lat;

    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const xi = polygon[i].lng;
        const yi = polygon[i].lat;
        const xj = polygon[j].lng;
        const yj = polygon[j].lat;

        const intersect =
            yi > y !== yj > y &&
            x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;

        if (intersect) inside = !inside;
    }

    return inside;
};

// exports.validateLocation = async (req,res) => {

//     const {location, isFaceVerified} = req.body;

//     if(isFaceVerified){

//         const { Attendance } = getModels(req);

//         const Office = await Office.findOne({name:"ahmedabad"});

//         if(location.accuracy > Office.allowedLocationAccuracy){
//             return res.status(400).message("Too Loo Location Accuracy!!");
//         }

//         const inside = isInsidePolygon(location,Office.geofance);

//         if(!inside){
//             return res.status(400).json({message: "Out of the office location"});
//         }

//         await Attendance.create({
//             tenant: req.params,
//             employee: req.user._id,
//             date:new Date(),
//             location,
//             status: "Present"
//         });

//         res.json({message : "Attendance Marked Successfully"});
//     }
//     else{
//         res.status(400).json({message: "Your Face is Not Verified"});
//     }
// }

exports.validateLocation = async (req, res) => {
    try {
        console.log("Tenant DB exists:", !!req.tenantDB);
        console.log("Request body:", req.body);


        Employee.updateOne(
            { _id: '69661f85507ce0cf47b618ae' },
            {
                $set: {
                    geofance: [
                        {
                            lat: 23.021288,
                            lng: 72.555100
                        },
                        {
                            lat: 23.021188,
                            lng: 72.554934
                        },
                        {
                            lat: 23.020960,
                            lng: 72.555106
                        },
                        {
                            lat: 23.021033,
                            lng: 72.555232
                        },
                    ]
                }
            });
        const { location, isFaceVerified, tenantId } = req.body;

        if (!isFaceVerified) {
            return res.status(400).json({ message: "Face verification required" });
        }

        if (!location || !location.lat || !location.lng) {
            return res.status(400).json({ message: "Location data is required" });
        }

        const { Attendance, Employee } = getModels(req);

        // Find office by tenantId from request body or from authenticated user
        const officeTenantId = tenantId || req.tenantId;
        console.log("🔍 Looking for office with tenantId:", officeTenantId);
        console.log("🔍 tenantId from body:", tenantId);
        console.log("🔍 tenantId from req:", req.tenantId);
        console.log("🔍 User info:", req.user);

        const employee = await Employee.findOne({ _id: '69662fbeb56bd4e7fefcf5fa' });
        console.log("📍 Office found:", employee);

        if (!employee) {
            // Let's check if ANY office exists
            const allEmployees = await Employee.find({}).limit(5);
            console.log("📋 All offices in DB (first 5):", allEmployees);
            return res.status(404).json({
                message: "Office not found for this tenant",
                debug: {
                    searchedTenantId: officeTenantId,
                    availableOfficeCount: allEmployees.length,
                    hint: "Please create a CompanyProfile record with the correct tenantId"
                }
            });
        }

        console.log("Accuracy:", location.accuracy);
        console.log("Allowed:", employee.allowedAccuracy);

        // Check location accuracy
        if (location.accuracy > employee.allowedAccuracy) {
            return res.status(400).json({
                message: `Location accuracy too low. Required: ${employee.allowedAccuracy}m, Got: ${location.accuracy}m`
            });
        }
        demoGeofance = [
            { "lat": 23.03010, "lng": 72.51790 },
            { "lat": 23.03010, "lng": 72.51830 },
            { "lat": 23.03040, "lng": 72.51830 },
            { "lat": 23.03040, "lng": 72.51790 }
        ]

        // Check if location is inside geofence
        if (employee.geofance && employee.geofance.length > 0) {
            const inside = isInsidePolygon(location, demoGeofance);

            if (!inside) {
                return res.status(400).json({ message: "You are outside the office location" });
            }
        }

        // Create attendance record
        const employeeId = req.user.id;
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        today.setHours(0, 0, 0, 0);
        const employee1 = await Employee.findOne({ _id: employeeId }).lean();
        console.log("Employee Name : ", employee1.firstName + " " + employee1.lastName);
        const employeeFullName = employee1.firstName + " " + employee1.lastName;

        // Check if attendance already exists for today
        let attendance = await Attendance.findOne({
            employee: employeeId,
            tenant: officeTenantId,
            date: today
        });

        if (attendance) {
            return res.status(400).json({
                message: "Attendance already marked for today",
                data: attendance
            });
        }

        // Create new attendance record
        attendance = new Attendance({
            tenant: officeTenantId,
            employee: employeeId,
            date: today,
            checkIn: now,
            status: 'present',
            logs: [{
                time: now,
                type: 'IN',
                location: `${location.lat}, ${location.lng}`,
                device: req.body.device || 'Face Recognition',
                ip: req.headers['x-forwarded-for']?.split(',')[0] || req.connection?.remoteAddress || 'unknown'
            }]
        });

        await attendance.save();

        res.json({
            message: "Attendance marked successfully",
            data: attendance
        });

    } catch (err) {
        console.error("❌ VALIDATE LOCATION ERROR:", err);
        return res.status(500).json({
            message: "Internal Server Error",
            error: err.message
        });
    }
};


const calculateWorkingHours = (logs = []) => {
    if (logs.length < 2) return 0;

    let totalMinutes = 0;
    let inTime = null;

    for (const log of logs) {
        if (log.type === 'IN') {
            inTime = new Date(log.time);
        } else if (log.type === 'OUT' && inTime) {
            const outTime = new Date(log.time);
            const duration = (outTime - inTime) / (1000 * 60); // Duration in minutes
            totalMinutes += duration;
            inTime = null;
        }
    }

    return parseFloat((totalMinutes / 60).toFixed(2));
};

// Helper: Validate Geo-fencing
const validateGeoFencing = (latitude, longitude, settings) => {
    if (!settings.geoFencingEnabled || !settings.officeLatitude || !settings.officeLongitude) {
        return { valid: true };
    }

    if (!latitude || !longitude) {
        return { valid: false, error: 'Location data required for geo-fencing' };
    }

    // Haversine formula to calculate distance
    const R = 6371e3; // Earth radius in meters
    const φ1 = settings.officeLatitude * Math.PI / 180;
    const φ2 = latitude * Math.PI / 180;
    const Δφ = (latitude - settings.officeLatitude) * Math.PI / 180;
    const Δλ = (longitude - settings.officeLongitude) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
        Math.cos(φ1) * Math.cos(φ2) *
        Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in meters

    const allowedRadius = settings.allowedRadiusMeters || 100;

    if (distance > allowedRadius) {
        return {
            valid: false,
            error: `Punch outside allowed radius. Distance: ${Math.round(distance)}m, Allowed: ${allowedRadius}m`
        };
    }

    return { valid: true, distance: Math.round(distance) };
};

// Helper: Validate IP Address
const validateIPAddress = (ipAddress, settings) => {
    if (!settings.ipRestrictionEnabled || !settings.allowedIPs || settings.allowedIPs.length === 0) {
        return { valid: true };
    }

    if (!ipAddress) {
        return { valid: false, error: 'IP address required for IP restriction' };
    }

    // Check if IP is in allowed list
    const isAllowed = settings.allowedIPs.some(allowedIP => {
        // Support CIDR notation (e.g., "192.168.1.0/24")
        if (allowedIP.includes('/')) {
            const [network, prefixLength] = allowedIP.split('/');
            return isIPInCIDR(ipAddress, network, parseInt(prefixLength));
        }
        // Exact match
        return ipAddress === allowedIP;
    });

    // Also check IP ranges if defined
    if (!isAllowed && settings.allowedIPRanges && settings.allowedIPRanges.length > 0) {
        const inRange = settings.allowedIPRanges.some(range => {
            if (range.includes('/')) {
                const [network, prefixLength] = range.split('/');
                return isIPInCIDR(ipAddress, network, parseInt(prefixLength));
            }
            return ipAddress.startsWith(range);
        });

        if (inRange) {
            return { valid: true };
        }
    }

    if (!isAllowed) {
        return { valid: false, error: `IP address ${ipAddress} not in allowed list` };
    }

    return { valid: true };
};

// Helper: Check if IP is in CIDR range
const isIPInCIDR = (ip, network, prefixLength) => {
    const ipNum = ipToNumber(ip);
    const networkNum = ipToNumber(network);
    const mask = (0xFFFFFFFF << (32 - prefixLength)) >>> 0;
    return (ipNum & mask) === (networkNum & mask);
};

// Helper: Convert IP to number
const ipToNumber = (ip) => {
    return ip.split('.').reduce((acc, octet) => (acc << 8) + parseInt(octet, 10), 0) >>> 0;
};

// Helper: Get client IP address
const getClientIP = (req) => {
    return req.headers['x-forwarded-for']?.split(',')[0] ||
        req.headers['x-real-ip'] ||
        req.connection?.remoteAddress ||
        req.socket?.remoteAddress ||
        'unknown';
};

// Helper: Calculate Overtime Hours
const calculateOvertimeHours = (workingHours, shiftStartTime, shiftEndTime, overtimeAfterShiftHours = true) => {
    if (!overtimeAfterShiftHours) return Math.max(0, workingHours - 8); // Default 8 hours standard

    // Calculate shift duration
    const [startHour, startMin] = shiftStartTime.split(':').map(Number);
    const [endHour, endMin] = shiftEndTime.split(':').map(Number);
    const shiftDuration = ((endHour * 60 + endMin) - (startHour * 60 + startMin)) / 60;

    return Math.max(0, workingHours - shiftDuration);
};

// 1. PUNCH IN / OUT (DYNAMIC) - With Policy Validation
exports.punch = async (req, res) => {
    try {
        const { Attendance, AttendanceSettings, AuditLog } = getModels(req);
        const employeeId = req.user.id;
        const tenantId = req.tenantId;
        const now = new Date();

        // Prefer client-provided local date to ensure alignment with dashboard
        let today;
        if (req.body.dateStr) {
            const [y, m, d] = req.body.dateStr.split('-').map(Number);
            today = new Date(y, m - 1, d);
            today.setHours(0, 0, 0, 0);
        } else {
            today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            today.setHours(0, 0, 0, 0);
        }

        let settings = await AttendanceSettings.findOne({ tenant: tenantId });
        if (!settings) {
            settings = new AttendanceSettings({ tenant: tenantId });
            await settings.save();
        }

        // ========== WEEKLY OFF VALIDATION ==========
        // Prevent punching in on configured weekly off days
        const dayOfWeek = today.getDay();
        const weeklyOffDays = settings.weeklyOffDays || [0];

        if (weeklyOffDays.includes(dayOfWeek)) {
            const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            const violationLog = new AuditLog({
                tenant: tenantId,
                entity: 'Attendance',
                entityId: employeeId,
                action: 'PUNCH_WEEKLY_OFF_VIOLATION',
                performedBy: employeeId,
                changes: { before: null, after: { day: dayNames[dayOfWeek], error: 'Attempted punch on weekly off day' } },
                meta: { employeeId, weeklyOffDay: dayOfWeek }
            });
            await violationLog.save();

            return res.status(403).json({
                error: `Cannot punch in on ${dayNames[dayOfWeek]}. It is configured as a weekly off day.`,
                code: 'WEEKLY_OFF_VIOLATION',
                day: dayNames[dayOfWeek]
            });
        }

        // ========== LOCATION VALIDATION ==========
        const clientIP = getClientIP(req);
        const { latitude, longitude } = req.body;

        // Geo-fencing validation
        if (settings.locationRestrictionMode === 'geo' || settings.locationRestrictionMode === 'both') {
            const geoValidation = validateGeoFencing(latitude, longitude, settings);
            if (!geoValidation.valid) {
                // Log violation
                const violationLog = new AuditLog({
                    tenant: tenantId,
                    entity: 'Attendance',
                    entityId: employeeId,
                    action: 'PUNCH_GEO_VIOLATION',
                    performedBy: employeeId,
                    changes: { before: null, after: { latitude, longitude, error: geoValidation.error } },
                    meta: { ip: clientIP, employeeId }
                });
                await violationLog.save();

                return res.status(403).json({
                    error: geoValidation.error,
                    code: 'GEO_FENCING_VIOLATION'
                });
            }
        }

        // IP restriction validation
        if (settings.locationRestrictionMode === 'ip' || settings.locationRestrictionMode === 'both') {
            const ipValidation = validateIPAddress(clientIP, settings);
            if (!ipValidation.valid) {
                // Log violation
                const violationLog = new AuditLog({
                    tenant: tenantId,
                    entity: 'Attendance',
                    entityId: employeeId,
                    action: 'PUNCH_IP_VIOLATION',
                    performedBy: employeeId,
                    changes: { before: null, after: { ip: clientIP, error: ipValidation.error } },
                    meta: { employeeId }
                });
                await violationLog.save();

                return res.status(403).json({
                    error: ipValidation.error,
                    code: 'IP_RESTRICTION_VIOLATION'
                });
            }
        }

        let attendance = await Attendance.findOne({
            employee: employeeId,
            tenant: tenantId,
            date: today
        });

        // ========== PUNCH MODE VALIDATION ==========
        if (!attendance) {
            // First punch of the day → Must be IN
            const [h, m] = settings.shiftStartTime.split(':').map(Number);
            const shiftStart = new Date(today);
            shiftStart.setHours(h, m, 0, 0);

            // isLate is true only if they cross the Grace + Late Mark Threshold? 
            // Usually: 
            // - Grace Time: 15 mins (Allowed late without marking 'Late')
            // - Late Mark Threshold: 30 mins (If after THIS, definitely 'Late')
            const lateThreshold = new Date(shiftStart.getTime() + (settings.lateMarkThresholdMinutes || settings.graceTimeMinutes || 0) * 60000);
            const isLate = now > lateThreshold;

            attendance = new Attendance({
                tenant: tenantId,
                employee: employeeId,
                date: today,
                checkIn: now,
                status: 'present', // Placeholder, will be re-evaluated on OUT
                isLate,
                logs: [{
                    time: now,
                    type: 'IN',
                    location: req.body.location || 'Remote',
                    device: req.body.device || 'Unknown',
                    ip: clientIP
                }]
            });
            await attendance.save();
            return res.json({ message: "Punched In", data: attendance });
        }

        // Attendance exists - determine next punch type
        const lastLog = attendance.logs[attendance.logs.length - 1];
        const nextPunchType = (lastLog && lastLog.type === 'IN') ? 'OUT' : 'IN';

        // ========== SINGLE PUNCH MODE VALIDATION ==========
        if (settings.punchMode === 'single') {
            if (nextPunchType === 'IN' && attendance.checkIn) {
                return res.status(400).json({
                    error: 'Single punch mode: Only one punch in allowed per day',
                    code: 'SINGLE_PUNCH_MODE_VIOLATION'
                });
            }
            if (nextPunchType === 'OUT' && attendance.checkOut) {
                return res.status(400).json({
                    error: 'Single punch mode: You have already completed your shift for today.',
                    code: 'SINGLE_PUNCH_MODE_VIOLATION'
                });
            }
        }

        // ========== MAX PUNCH LIMIT VALIDATION ==========
        if (settings.punchMode === 'multiple') {
            const currentPunchCount = attendance.logs.length;
            if (currentPunchCount >= settings.maxPunchesPerDay) {
                if (settings.maxPunchAction === 'block') {
                    return res.status(400).json({
                        error: `Maximum punch limit reached (${settings.maxPunchesPerDay}). Contact HR for manual override.`,
                        code: 'MAX_PUNCH_LIMIT_EXCEEDED'
                    });
                }
            }
        }

        // ========== EARLY OUT VALIDATION (On OUT punch) ==========
        let isEarlyOut = attendance.isEarlyOut;
        if (nextPunchType === 'OUT') {
            const [eH, eM] = settings.shiftEndTime.split(':').map(Number);
            const shiftEnd = new Date(today);
            shiftEnd.setHours(eH, eM, 0, 0);
            isEarlyOut = now < shiftEnd;
        }

        // Add new punch log
        attendance.logs.push({
            time: now,
            type: nextPunchType,
            location: req.body.location || 'Remote',
            device: req.body.device || 'Unknown',
            ip: clientIP
        });

        // Update timestamps
        if (nextPunchType === 'IN') {
            // Keep the first checkIn of the day
            if (!attendance.checkIn) attendance.checkIn = now;
        } else {
            // Always update checkOut with the latest OUT time
            attendance.checkOut = now;
            attendance.isEarlyOut = isEarlyOut;
        }

        // ========== CALCULATE WORKING HOURS ==========
        // Always sum logs to avoid issues with multiple punches
        attendance.workingHours = calculateWorkingHours(attendance.logs);

        // ========== OVERTIME ==========
        if (settings.overtimeAllowed && attendance.workingHours > 0) {
            attendance.overtimeHours = calculateOvertimeHours(
                attendance.workingHours,
                settings.shiftStartTime,
                settings.shiftEndTime,
                settings.overtimeAfterShiftHours
            );
        }

        // ========== RE-EVALUATE STATUS (Policy Thresholds) ==========
        let newStatus = attendance.status;

        // Skip re-evaluation if it's already a special status like leave/holiday manually set
        if (!['leave', 'holiday', 'weekly_off'].includes(attendance.status)) {
            if (attendance.workingHours >= settings.fullDayThresholdHours) {
                newStatus = 'present';
            } else if (attendance.workingHours >= settings.halfDayThresholdHours) {
                newStatus = 'half_day';
            } else {
                // If they haven't worked enough yet, they are technically 'absent' or 'present' (until shift end)
                // For better UX, if shift is still ongoing, we can keep it as 'present' label
                newStatus = attendance.workingHours > 0 ? 'half_day' : 'present';
                // Actually, let's follow the threshold strictly for final result
                if (nextPunchType === 'OUT') {
                    if (attendance.workingHours < settings.halfDayThresholdHours) {
                        newStatus = 'absent';
                    }
                }
            }
        }

        attendance.status = newStatus;
        await attendance.save();

        res.json({
            message: `Successfully Punched ${nextPunchType}`,
            data: attendance,
            policy: {
                punchMode: settings.punchMode,
                isLate: attendance.isLate,
                isEarlyOut: attendance.isEarlyOut,
                workingHours: attendance.workingHours
            }
        });

    } catch (error) {
        console.error("Punch error:", error);
        res.status(500).json({ error: error.message });
    }
};

// 2. GET MY ATTENDANCE (Employee View)
exports.getMyAttendance = async (req, res) => {
    try {
        const { Attendance, Employee, AttendanceSettings } = getModels(req);
        const { month, year, employeeId } = req.query;

        // Target Employee: either the self or requested ID (RBAC check)
        let targetId = req.user.id;

        if (employeeId && employeeId !== req.user.id) {
            // If requesting someone else, must be Manager or HR
            if (req.user.role === 'hr') {
                targetId = employeeId;
            } else if (req.user.role === 'manager') {
                // Verify if target reports to this manager
                const isReport = await Employee.findOne({ _id: employeeId, manager: req.user.id, tenant: req.tenantId });
                if (!isReport) return res.status(403).json({ error: "Unauthorized access to employee data" });
                targetId = employeeId;
            } else {
                return res.status(403).json({ error: "Access denied" });
            }
        }

        const filter = {
            employee: targetId,
            tenant: req.tenantId
        };

        if (month && year) {
            const startDate = new Date(year, month - 1, 1);
            const endDate = new Date(year, month, 0);
            filter.date = { $gte: startDate, $lte: endDate };
        }

        // Fetch attendance data
        const data = await Attendance.find(filter).sort({ date: 1 })
            .populate('employee', 'firstName lastName employeeId');

        // Fetch settings to check weekly offs
        const settings = await AttendanceSettings.findOne({ tenant: req.tenantId });
        const weeklyOffDays = settings?.weeklyOffDays || [0];

        console.log(`\n📊 [getMyAttendance] Fetched ${data.length} records. Weekly off days: [${weeklyOffDays.join(', ')}]`);

        // CRITICAL FIX: Override ANY status to 'weekly_off' if day matches configured weekly off
        const correctedData = data.map(att => {
            const dateObj = new Date(att.date);
            const dayOfWeek = dateObj.getDay();
            const dateStr = att.date.toISOString().split('T')[0];
            const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

            // If this day is a configured weekly off, ALWAYS set status to 'weekly_off'
            if (weeklyOffDays.includes(dayOfWeek)) {
                const oldStatus = att.status;
                console.log(`🔧 [CORRECTION] ${dateStr} (${dayNames[dayOfWeek]}): "${oldStatus}" → "weekly_off"`);

                const corrected = att.toObject ? att.toObject() : JSON.parse(JSON.stringify(att));
                corrected.status = 'weekly_off';
                corrected.correctedBySystem = true;
                return corrected;
            }

            return att.toObject ? att.toObject() : att;
        });

        console.log(`✅ [getMyAttendance] Returning ${correctedData.length} corrected records\n`);
        res.json(correctedData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 3. GET TEAM ATTENDANCE (Manager View)
exports.getTeamAttendance = async (req, res) => {
    try {
        const { Attendance, Employee } = getModels(req);
        const managerId = req.user.id;

        // Find direct reports
        const reports = await Employee.find({ manager: managerId, tenant: req.tenantId }).select('_id');
        const reportIds = reports.map(r => r._id);

        const { date } = req.query;
        const queryDate = date ? new Date(date) : new Date();
        const start = new Date(queryDate.setHours(0, 0, 0, 0));
        const end = new Date(queryDate.setHours(23, 59, 59, 999));

        const data = await Attendance.find({
            employee: { $in: reportIds },
            tenant: req.tenantId,
            date: { $gte: start, $lte: end }
        }).populate('employee', 'firstName lastName employeeId profilePic');

        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 4. GET ALL ATTENDANCE (HR View)
exports.getAllAttendance = async (req, res) => {
    try {
        const { Attendance } = getModels(req);
        const { date, departmentId } = req.query;

        let query = { tenant: req.tenantId };
        if (date) {
            const d = new Date(date);
            query.date = { $gte: new Date(d.setHours(0, 0, 0, 0)), $lte: new Date(d.setHours(23, 59, 59, 999)) };
        }

        const data = await Attendance.find(query)
            .populate('employee', 'firstName lastName employeeId departmentId role')
            .sort({ date: -1 });

        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 5. ATTENDANCE SETTINGS (HR)
exports.getSettings = async (req, res) => {
    try {
        const { AttendanceSettings } = getModels(req);
        let settings = await AttendanceSettings.findOne({ tenant: req.tenantId });
        if (!settings) {
            settings = new AttendanceSettings({ tenant: req.tenantId });
            await settings.save();
        }
        res.json(settings);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateSettings = async (req, res) => {
    try {
        const { AttendanceSettings, AuditLog } = getModels(req);

        // Get existing settings for audit log
        const existingSettings = await AttendanceSettings.findOne({ tenant: req.tenantId });
        const before = existingSettings ? existingSettings.toObject() : null;

        // Filter out empty IP addresses
        const updateData = { ...req.body, updatedBy: req.user.id };
        if (updateData.allowedIPs) {
            updateData.allowedIPs = updateData.allowedIPs.filter(ip => ip && ip.trim() !== '');
        }
        if (updateData.allowedIPRanges) {
            updateData.allowedIPRanges = updateData.allowedIPRanges.filter(range => range && range.trim() !== '');
        }

        const settings = await AttendanceSettings.findOneAndUpdate(
            { tenant: req.tenantId },
            updateData,
            { new: true, upsert: true }
        );

        // Audit log the settings update
        const auditLog = new AuditLog({
            tenant: req.tenantId,
            entity: 'AttendanceSettings',
            entityId: settings._id,
            action: 'ATTENDANCE_SETTINGS_UPDATED',
            performedBy: req.user.id,
            changes: {
                before,
                after: settings.toObject()
            },
            meta: { settingsType: 'punch_policy' }
        });
        await auditLog.save();

        res.json({ message: "Settings updated", data: settings });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 6. MANUAL OVERRIDE (HR)
exports.override = async (req, res) => {
    try {
        const { Attendance, AuditLog } = getModels(req);
        const { employeeId, date, status, checkIn, checkOut, reason } = req.body;

        if (!reason) return res.status(400).json({ error: "Reason is mandatory for manual override" });

        const targetDate = new Date(new Date(date).setHours(0, 0, 0, 0));

        let attendance = await Attendance.findOne({ employee: employeeId, date: targetDate, tenant: req.tenantId });
        const before = attendance ? attendance.toObject() : null;

        if (!attendance) {
            attendance = new Attendance({ employee: employeeId, date: targetDate, tenant: req.tenantId });
        }

        attendance.status = status;
        if (checkIn) attendance.checkIn = checkIn;
        if (checkOut) attendance.checkOut = checkOut;
        attendance.isManualOverride = true;
        attendance.overrideReason = reason;
        attendance.approvedBy = req.user.id;

        await attendance.save();

        // Log the change
        const log = new AuditLog({
            tenant: req.tenantId,
            entity: 'Attendance',
            entityId: attendance._id,
            action: 'MANUAL_OVERRIDE',
            performedBy: req.user.id,
            changes: { before, after: attendance.toObject() },
            meta: { reason }
        });
        await log.save();

        res.json({ message: "Attendance overridden successfully", data: attendance });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 7. GET ATTENDANCE CALENDAR (HR-Managed Calendar View)
// This generates a calendar view with priority: Holiday > Weekly Off > Attendance Status > Not Marked
exports.getCalendar = async (req, res) => {
    try {
        const { Attendance, AttendanceSettings, Holiday } = getModels(req);
        const { year, month, employeeId } = req.query;
        const tenantId = req.tenantId;

        // Get target year/month (default to current)
        const targetYear = year ? parseInt(year) : new Date().getFullYear();
        const targetMonth = month ? parseInt(month) - 1 : new Date().getMonth(); // month is 0-indexed

        // Calculate date range for the month
        const startDate = new Date(targetYear, targetMonth, 1);
        const endDate = new Date(targetYear, targetMonth + 1, 0, 23, 59, 59);

        // Get settings (weekly off days, shifts, etc.)
        let settings = await AttendanceSettings.findOne({ tenant: tenantId });
        if (!settings) {
            settings = { weeklyOffDays: [0] }; // Default to Sunday
        }

        // Get holidays for the month (including past and future for full visibility)
        const holidays = await Holiday.find({
            tenant: tenantId,
            date: { $gte: startDate, $lte: endDate }
        }).sort({ date: 1 });

        // Create holiday map for quick lookup
        const holidayMap = {};
        holidays.forEach(h => {
            const dateStr = h.date.toISOString().split('T')[0];
            holidayMap[dateStr] = {
                name: h.name,
                type: h.type,
                description: h.description || ''
            };
        });

        // Get attendance records if employeeId is provided (for employee-specific calendar)
        let attendanceMap = {};
        if (employeeId) {
            const attendance = await Attendance.find({
                tenant: tenantId,
                employee: employeeId,
                date: { $gte: startDate, $lte: endDate }
            }).sort({ date: 1 });

            attendance.forEach(a => {
                const dateStr = a.date.toISOString().split('T')[0];
                attendanceMap[dateStr] = {
                    status: a.status,
                    checkIn: a.checkIn,
                    checkOut: a.checkOut,
                    workingHours: a.workingHours,
                    isLate: a.isLate,
                    isEarlyOut: a.isEarlyOut
                };
            });
        }

        // Generate calendar days with priority rules
        const calendarDays = [];
        const lastDate = endDate.getDate();

        for (let day = 1; day <= lastDate; day++) {
            const date = new Date(targetYear, targetMonth, day);
            const dateStr = date.toISOString().split('T')[0];
            const dayOfWeek = date.getDay();
            const isWeeklyOff = settings.weeklyOffDays?.includes(dayOfWeek) || false;

            // Apply priority: 1. Holiday 2. Weekly Off 3. Attendance 4. Not Marked
            let status = 'not_marked';
            let displayLabel = '';
            let holiday = null;

            if (holidayMap[dateStr]) {
                // Priority 1: Holiday
                status = 'holiday';
                displayLabel = holidayMap[dateStr].name;
                holiday = holidayMap[dateStr];
            } else if (isWeeklyOff) {
                // Priority 2: Weekly Off
                status = 'weekly_off';
                displayLabel = 'Weekly Off';
            } else if (attendanceMap[dateStr]) {
                // Priority 3: Attendance Status
                status = attendanceMap[dateStr].status;
                displayLabel = attendanceMap[dateStr].status;
            }

            calendarDays.push({
                date: dateStr,
                day: day,
                dayOfWeek: dayOfWeek,
                dayName: date.toLocaleDateString('en-US', { weekday: 'short' }),
                status: status,
                displayLabel: displayLabel,
                isWeeklyOff: isWeeklyOff,
                isHoliday: !!holidayMap[dateStr],
                holiday: holiday,
                attendance: attendanceMap[dateStr] || null,
                isPast: dateStr < new Date().toISOString().split('T')[0],
                isToday: dateStr === new Date().toISOString().split('T')[0],
                isFuture: dateStr > new Date().toISOString().split('T')[0]
            });
        }

        res.json({
            year: targetYear,
            month: targetMonth + 1, // Return 1-indexed for frontend
            settings: {
                weeklyOffDays: settings.weeklyOffDays || [0],
                shiftStartTime: settings.shiftStartTime || "09:00",
                shiftEndTime: settings.shiftEndTime || "18:00"
            },
            holidays: holidays,
            calendarDays: calendarDays
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 8. GET TODAY SUMMARY (For Employee Dashboard)
exports.getTodaySummary = async (req, res) => {
    try {
        const { Attendance } = getModels(req);
        const employeeId = req.user.id;
        const tenantId = req.tenantId;

        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

        const attendance = await Attendance.findOne({
            tenant: tenantId,
            employee: employeeId,
            date: today
        });

        if (!attendance) {
            return res.json({
                totalPunches: 0,
                totalIn: 0,
                totalOut: 0,
                workingHours: 0,
                status: 'Not Marked',
                firstPunch: null,
                lastPunch: null,
                logs: []
            });
        }

        let totalIn = 0;
        let totalOut = 0;
        attendance.logs.forEach(log => {
            if (log.type === 'IN') totalIn++;
            if (log.type === 'OUT') totalOut++;
        });

        res.json({
            totalPunches: attendance.logs.length,
            totalIn,
            totalOut,
            workingHours: attendance.workingHours || 0,
            status: attendance.status || 'Not Marked',
            firstPunch: attendance.checkIn || null,
            lastPunch: attendance.checkOut || null,
            logs: attendance.logs
        });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 9. GET HR DASHBOARD STATS (For HR/Admin Dashboard)
exports.getHRStats = async (req, res) => {
    try {
        const { Attendance, Employee } = getModels(req);
        const tenantId = req.tenantId;
        const { date } = req.query;

        // Determine target date (default today)
        const targetDateStr = date || new Date().toISOString().split('T')[0];
        const [y, m, d] = targetDateStr.split('-').map(Number);
        const targetDate = new Date(y, m - 1, d); // Local midnight

        // Fetch all attendance for today
        const attendances = await Attendance.find({
            tenant: tenantId,
            date: targetDate
        });

        const totalPunchedIn = attendances.length;

        let multiplePunches = 0;
        let missingPunchOut = 0;
        let totalWorkingHours = 0;

        attendances.forEach(att => {
            // Multiple punches: if logs > 2 (meaning more than just IN-OUT pair)
            if (att.logs && att.logs.length > 2) {
                multiplePunches++;
            }

            // Missing Punch Out: user checked in roughly (logs not empty) but no checkOut yet
            // (Only counts if they are not currently working late? Simple logic: !checkOut)
            if (att.checkIn && !att.checkOut) {
                missingPunchOut++;
            }

            totalWorkingHours += (att.workingHours || 0);
        });

        const avgWorkingHours = totalPunchedIn > 0 ? (totalWorkingHours / totalPunchedIn).toFixed(2) : 0;

        res.json({
            date: targetDateStr,
            totalPunchedIn,
            multiplePunches,
            missingPunchOut,
            avgWorkingHours
        });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

/**
 * POST /api/attendance/upload-excel
 * Upload attendance from Excel
 */
exports.uploadExcel = async (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ error: "Excel file is required" });

        const { Attendance, Employee, AuditLog, AttendanceSettings } = getModels(req);
        const tenantId = req.tenantId;

        const workbook = XLSX.read(req.file.buffer, { type: 'buffer', cellDates: true });
        const sheetName = workbook.SheetNames[0];
        const rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: "" });

        if (rows.length === 0) return res.status(400).json({ error: "Excel sheet is empty" });

        const results = {
            success: 0,
            failed: 0,
            errors: []
        };

        // Cache settings
        let settings = await AttendanceSettings.findOne({ tenant: tenantId });
        if (!settings) settings = new AttendanceSettings({ tenant: tenantId });

        // Normalize header names
        const normalize = (s) => s ? s.toString().toLowerCase().replace(/\s/g, '').replace(/[^a-z0-9]/g, '') : '';

        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            const rowIdx = i + 2; // 1-indexed + header row

            try {
                // Find column names
                let empIdVal = "";
                let dateVal = null;
                let statusVal = "";
                let checkInVal = null;
                let checkOutVal = null;

                for (const key of Object.keys(row)) {
                    const normKey = normalize(key);
                    const val = row[key];

                    if (normKey.includes('employeeid') || normKey.includes('empid') || normKey === 'id' || normKey === 'code') {
                        empIdVal = val.toString().trim();
                    } else if (normKey === 'date' || normKey.includes('attendancedate') || normKey.includes('punchdate')) {
                        dateVal = val;
                    } else if (normKey === 'status') {
                        statusVal = val.toString().trim().toLowerCase();
                    } else if (normKey.includes('checkin') || normKey.includes('punchin') || normKey === 'in') {
                        checkInVal = val;
                    } else if (normKey.includes('checkout') || normKey.includes('punchout') || normKey === 'out') {
                        checkOutVal = val;
                    }
                }

                if (!empIdVal) throw new Error("Employee ID is missing");
                if (!dateVal) throw new Error("Date is missing");

                // Find Employee
                const employee = await Employee.findOne({
                    tenant: tenantId,
                    $or: [{ employeeId: empIdVal }, { customId: empIdVal }]
                });
                if (!employee) throw new Error(`Employee not found with ID: ${empIdVal}`);

                // Process Date
                let attendanceDate = new Date(dateVal);
                if (isNaN(attendanceDate.getTime())) throw new Error(`Invalid date format: ${dateVal}`);
                attendanceDate.setHours(0, 0, 0, 0);

                // Default status if missing
                if (!statusVal) statusVal = 'present';

                // Find or Create Attendance
                let attendance = await Attendance.findOne({
                    tenant: tenantId,
                    employee: employee._id,
                    date: attendanceDate
                });

                if (!attendance) {
                    attendance = new Attendance({
                        tenant: tenantId,
                        employee: employee._id,
                        date: attendanceDate
                    });
                }

                attendance.status = statusVal;

                // Process Punch Times if they are Date objects or strings
                const parseTime = (val, baseDate) => {
                    if (!val) return null;
                    if (val instanceof Date) return val;
                    // Try to parse string time like "09:00"
                    if (typeof val === 'string' && val.includes(':')) {
                        const [h, m] = val.split(':').map(Number);
                        const d = new Date(baseDate);
                        d.setHours(h, m || 0, 0, 0);
                        return d;
                    }
                    return null;
                };

                const checkIn = parseTime(checkInVal, attendanceDate);
                const checkOut = parseTime(checkOutVal, attendanceDate);

                if (checkIn) {
                    attendance.checkIn = checkIn;
                    // Also check late mark
                    const [h, m] = settings.shiftStartTime.split(':').map(Number);
                    const shiftStart = new Date(attendanceDate);
                    shiftStart.setHours(h, m, 0, 0);
                    const grace = settings.graceTimeMinutes || 0;
                    if (checkIn > new Date(shiftStart.getTime() + grace * 60000)) {
                        attendance.isLate = true;
                    }
                }

                if (checkOut) {
                    attendance.checkOut = checkOut;
                    // Also check early out
                    const [h, m] = settings.shiftEndTime.split(':').map(Number);
                    const shiftEnd = new Date(attendanceDate);
                    shiftEnd.setHours(h, m, 0, 0);
                    if (checkOut < shiftEnd) {
                        attendance.isEarlyOut = true;
                    }
                }

                // Sync Logs for consistency if we have punch times
                if (checkIn || checkOut) {
                    attendance.logs = [];
                    if (checkIn) attendance.logs.push({ time: checkIn, type: 'IN', location: 'Excel Upload', device: 'System' });
                    if (checkOut) attendance.logs.push({ time: checkOut, type: 'OUT', location: 'Excel Upload', device: 'System' });

                    attendance.workingHours = calculateWorkingHours(attendance.logs);
                }

                attendance.isManualOverride = true;
                attendance.overrideReason = "Bulk Excel Upload";
                attendance.approvedBy = req.user.id;

                await attendance.save();
                results.success++;

            } catch (err) {
                results.failed++;
                results.errors.push({ row: rowIdx, error: err.message });
            }
        }

        // Log the bulk action
        const bulkLog = new AuditLog({
            tenant: tenantId,
            entity: 'AttendanceBatch',
            entityId: req.user.id,
            action: 'BULK_UPLOAD_EXCEL',
            performedBy: req.user.id,
            meta: {
                file: req.file.originalname,
                successCount: results.success,
                failCount: results.failed
            }
        });
        await bulkLog.save();

        res.json({
            message: `Bulk upload completed: ${results.success} succeeded, ${results.failed} failed.`,
            data: results
        });

    } catch (error) {
        console.error("Bulk upload error:", error);
        res.status(500).json({ error: error.message });
    }
};

// Bulk Upload from JSON data (for frontend Excel import)
exports.bulkUpload = async (req, res) => {
    try {
        const { records } = req.body;

        if (!records || !Array.isArray(records)) {
            return res.status(400).json({
                success: false,
                message: "Records must be an array"
            });
        }

        if (records.length === 0) {
            return res.status(400).json({
                success: false,
                message: "No records provided"
            });
        }

        const { Attendance, Employee, AuditLog, AttendanceSettings } = getModels(req);
        const tenantId = req.tenantId;
        const userId = req.userId;

        const results = {
            uploadedCount: 0,
            failedCount: 0,
            errors: []
        };

        // Cache settings
        let settings = await AttendanceSettings.findOne({ tenant: tenantId });
        if (!settings) settings = new AttendanceSettings({ tenant: tenantId });

        // Normalize header names
        const normalize = (s) => s ? s.toString().toLowerCase().replace(/\s/g, '').replace(/[^a-z0-9]/g, '') : '';

        for (let i = 0; i < records.length; i++) {
            const row = records[i];
            const rowIdx = i + 2; // 1-indexed + header row

            try {
                // Find column names
                let empIdVal = "";
                let dateVal = null;
                let statusVal = "";
                let checkInVal = null;
                let checkOutVal = null;

                for (const key of Object.keys(row)) {
                    const normKey = normalize(key);
                    const val = row[key];

                    if (normKey.includes('employeeid') || normKey.includes('empid') || normKey === 'id' || normKey === 'code') {
                        empIdVal = val ? val.toString().trim() : "";
                    } else if (normKey === 'date' || normKey.includes('attendancedate') || normKey.includes('punchdate')) {
                        dateVal = val;
                    } else if (normKey === 'status') {
                        statusVal = val ? val.toString().trim().toLowerCase() : "";
                    } else if (normKey.includes('checkin') || normKey.includes('punchin') || normKey === 'in') {
                        checkInVal = val;
                    } else if (normKey.includes('checkout') || normKey.includes('punchout') || normKey === 'out') {
                        checkOutVal = val;
                    }
                }

                if (!empIdVal) throw new Error("Employee ID is missing");
                if (!dateVal) throw new Error("Date is missing");

                // Find Employee
                const employee = await Employee.findOne({
                    tenant: tenantId,
                    $or: [{ employeeId: empIdVal }, { customId: empIdVal }]
                });
                if (!employee) throw new Error(`Employee not found with ID: ${empIdVal}`);

                // Process Date
                let attendanceDate = new Date(dateVal);
                if (isNaN(attendanceDate.getTime())) throw new Error(`Invalid date format: ${dateVal}`);
                attendanceDate.setHours(0, 0, 0, 0);

                // Default status if missing
                if (!statusVal) statusVal = 'present';

                // Validate status
                const validStatuses = ['present', 'absent', 'leave', 'holiday', 'weekly_off', 'half_day', 'missed_punch'];
                if (!validStatuses.includes(statusVal)) {
                    statusVal = 'present'; // Default to present if invalid
                }

                // Process check-in/out times
                let checkInTime = null;
                let checkOutTime = null;

                if (checkInVal) {
                    checkInTime = new Date(checkInVal);
                    if (isNaN(checkInTime.getTime())) checkInTime = null;
                }

                if (checkOutVal) {
                    checkOutTime = new Date(checkOutVal);
                    if (isNaN(checkOutTime.getTime())) checkOutTime = null;
                }

                // Check if record already exists
                let attendance = await Attendance.findOne({
                    tenant: tenantId,
                    employee: employee._id,
                    date: attendanceDate
                });

                const attendanceData = {
                    tenant: tenantId,
                    employee: employee._id,
                    date: attendanceDate,
                    status: statusVal,
                    checkIn: checkInTime,
                    checkOut: checkOutTime,
                    ipAddress: req.ip || '0.0.0.0',
                    userAgent: req.get('user-agent') || ''
                };

                if (attendance) {
                    // Update existing
                    Object.assign(attendance, attendanceData);
                    await attendance.save();
                } else {
                    // Create new
                    attendance = new Attendance(attendanceData);
                    await attendance.save();
                }

                results.uploadedCount++;

            } catch (error) {
                results.failedCount++;
                results.errors.push(`Row ${rowIdx}: ${error.message}`);
            }
        }

        // Log audit
        try {
            const AuditLog = require('../models/auditLog.model');
            const auditLog = new AuditLog({
                tenant: tenantId,
                user: userId,
                action: 'BULK_UPLOAD_ATTENDANCE',
                module: 'Attendance',
                changes: {
                    uploadedCount: results.uploadedCount,
                    failedCount: results.failedCount
                }
            });
            await auditLog.save();
        } catch (e) {
            console.error('Audit log error:', e);
        }

        res.json({
            success: true,
            uploadedCount: results.uploadedCount,
            failedCount: results.failedCount,
            errors: results.errors,
            message: `Uploaded ${results.uploadedCount} records successfully${results.failedCount > 0 ? ` (${results.failedCount} failed)` : ''}`
        });

    } catch (error) {
        console.error("Bulk upload error:", error);
        res.status(500).json({
            success: false,
            message: error.message || 'Error uploading records'
        });
    }
};

// ========== FACE AUTHENTICATION ENDPOINTS ==========

// 🔹 Register Face Data
// exports.registerFace = async (req, res) => {
//     try {
//         const { faceImageData, registrationNotes } = req.body;
//         const employeeId = req.user.id;
//         const tenantId = req.tenantId || req.body.tenantId;

//         if (!faceImageData) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'Face image data is required'
//             });
//         }

//         const { FaceData } = getModels(req);

//         // Check if employee already has a registered face
//         const existingFace = await FaceData.findOne({
//             tenant: tenantId,
//             employee: employeeId,
//             status: 'ACTIVE'
//         });

//         if (existingFace) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'This employee already has a registered face. Please delete or update the existing registration.'
//             });
//         }

//         // Validate image data
//         if (!faceImageData.startsWith('data:image') || faceImageData.length < 1000) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'Invalid face image data. Please provide a valid base64 encoded image.'
//             });
//         }

//         // Generate required embedding and quality metrics

//         // Generate deterministic embedding from image
//         const imageBuffer = Buffer.from(faceImageData.split('base64,')[1] || faceImageData, 'base64');
//         const hash = crypto.createHash('sha256').update(imageBuffer).digest();

//         // Generate 128-dim embedding
//         const embedding = new Array(128);
//         for (let i = 0; i < 128; i++) {
//             const byteIndex = (i * 2) % hash.length;
//             const nextByteIndex = (byteIndex + 1) % hash.length;
//             const value = (hash[byteIndex] + hash[nextByteIndex]) / 512 - 1;
//             embedding[i] = value;
//         }

//         // Encrypt embedding
//         const encryptionKey = crypto.randomBytes(32);
//         const iv = crypto.randomBytes(16);
//         const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey, iv);
//         const embeddingBuffer = Buffer.from(JSON.stringify(embedding));
//         const encrypted = Buffer.concat([cipher.update(embeddingBuffer), cipher.final()]);
//         const authTag = cipher.getAuthTag();

//         // Generate quality metrics (mock values for now)
//         const quality = {
//             sharpness: 75,
//             brightness: 120,
//             contrast: 45,
//             confidence: 92
//         };

//         // Generate detection bbox (mock values)
//         const detection = {
//             bbox: {
//                 x: 50,
//                 y: 50,
//                 width: 200,
//                 height: 250
//             }
//         };

//         // Create new face record with all required fields
//         const faceData = new FaceData({
//             tenant: tenantId,
//             employee: employeeId,
//             faceEmbedding: {
//                 encrypted: encrypted.toString('hex'),
//                 iv: iv.toString('hex'),
//                 authTag: authTag.toString('hex'),
//                 algorithm: 'aes-256-gcm'
//             },
//             quality: quality,
//             detection: detection,
//             registration: {
//                 registeredAt: new Date(),
//                 registeredBy: req.user.id,
//                 registrationNotes: registrationNotes,
//                 deviceInfo: req.headers['user-agent'],
//                 ipAddress: req.headers['x-forwarded-for']?.split(',')[0] || req.connection?.remoteAddress,
//                 consentVersion: 1,
//                 consentGiven: true,
//                 consentGivenAt: new Date()
//             },
//             status: 'ACTIVE',
//             isVerified: true,
//             verification: {
//                 verifiedAt: new Date(),
//                 verifiedBy: req.user.id
//             },
//             liveness: {
//                 status: 'PASSED',
//                 confidence: 90,
//                 method: 'TEXTURE'
//             },
//             model: {
//                 name: 'facenet-mobilenet-v2',
//                 version: '1.0.0',
//                 generatedAt: new Date()
//             }
//         });

//         await faceData.save();

//         res.status(201).json({
//             success: true,
//             message: 'Face registered successfully',
//             data: {
//                 faceDataId: faceData._id,
//                 employeeId: faceData.employee,
//                 registeredAt: faceData.registration.registeredAt,
//                 quality: quality,
//                 embedding: {
//                     dimension: 128,
//                     mode: 'deterministic'
//                 }
//             }
//         });

//     } catch (err) {
//         console.error('Face registration error:', err);
//         res.status(500).json({
//             success: false,
//             message: 'Face registration failed',
//             error: err.message
//         });
//     }
// };

// exports.registerFace = async (req, res) => {
//   try {
//     const {
//       employeeId,
//       faceEmbedding,
//       registrationNotes,
//       consentGiven
//     } = req.body;

//     const tenantId = req.tenantId || req.body.tenantId;

//     if (!employeeId) {
//       return res.status(400).json({
//         success: false,
//         message: 'Employee ID is required'
//       });
//     }

//     // 1️⃣ Validate embedding
//     if (
//       !Array.isArray(faceEmbedding) ||
//       faceEmbedding.length !== 128
//     ) {
//       return res.status(400).json({
//         success: false,
//         message: 'Invalid face embedding. Expected 128-dimensional array.'
//       });
//     }

//     const { FaceData } = getModels(req);

//     // 2️⃣ Check existing face
//     const existingFace = await FaceData.findOne({
//       tenant: tenantId,
//       employee: employeeId,
//       status: 'ACTIVE'
//     });

//     if (existingFace) {
//       return res.status(400).json({
//         success: false,
//         message: 'This employee already has a registered face.'
//       });
//     }

//     // 3️⃣ Encrypt embedding (AES-256-GCM)
//     const encryptionKey = crypto.randomBytes(32);
//     const iv = crypto.randomBytes(16);

//     const cipher = crypto.createCipheriv('aes-256-gcm', MASTER_FACE_KEY, iv);
//     const embeddingBuffer = Buffer.from(JSON.stringify(faceEmbedding));
//     const encrypted = Buffer.concat([
//       cipher.update(embeddingBuffer),
//       cipher.final()
//     ]);
//     const authTag = cipher.getAuthTag();

//     // ⚠️ IMPORTANT:
//     // You MUST store encryptionKey securely (KMS / env / vault)
//     // For demo, this assumes key is retrievable later
//     // Do NOT lose this key

//     // 4️⃣ Quality & metadata (basic but real)
//     const quality = {
//       confidence: 90
//     };

//     const detection = {
//       model: 'face-api.js',
//       descriptorLength: 128
//     };

//     // 5️⃣ Create DB record
//     const faceData = new FaceData({
//       tenant: tenantId,
//       employee: employeeId,
//       faceEmbedding: {
//         encrypted: encrypted.toString('hex'),
//         iv: iv.toString('hex'),
//         authTag: authTag.toString('hex'),
//         algorithm: 'aes-256-gcm'
//         // encryptionKeyId: 'kms-key-id' (recommended)
//       },
//       quality,
//       detection,
//       registration: {
//         registeredAt: new Date(),
//         registeredBy: employeeId,
//         registrationNotes,
//         deviceInfo: req.headers['user-agent'],
//         ipAddress:
//           req.headers['x-forwarded-for']?.split(',')[0] ||
//           req.connection?.remoteAddress,
//         consentVersion: 1,
//         consentGiven: consentGiven === true,
//         consentGivenAt: new Date()
//       },
//       status: 'ACTIVE',
//       isVerified: true,
//       verification: {
//         verifiedAt: new Date(),
//         verifiedBy: employeeId
//       },
//       model: {
//         name: 'face-api.js',
//         version: 'ssd-mobilenetv1',
//         embeddingSize: 128,
//         generatedAt: new Date()
//       }
//     });

//     await faceData.save();

//     return res.status(201).json({
//       success: true,
//       message: 'Face registered successfully',
//       data: {
//         faceDataId: faceData._id,
//         employeeId: faceData.employee,
//         registeredAt: faceData.registration.registeredAt,
//         embedding: {
//           dimension: 128,
//           source: 'face-api.js'
//         }
//       }
//     });

//   } catch (err) {
//     console.error('Face registration error:', err);
//     return res.status(500).json({
//       success: false,
//       message: 'Face registration failed',
//       error: err.message
//     });
//   }
// };



exports.registerFace = async (req, res) => {
  try {
    const { faceEmbedding, registrationNotes, consentGiven, employeeName } = req.body;
    const userId = req.user?.id; // MUST use authenticated user, NOT user input
    const tenantId = req.tenantId;

    console.log('📝 registerFace called with:', { 
      embeddingLength: faceEmbedding?.length, 
      consentGiven,
      userId: userId,
      tenantId 
    });

    // --------- SECURITY CHECK: User must be authenticated ----------
    if (!userId) {
      return res.status(401).json({
        success: false,
        message: 'Unauthorized. Please login first.'
      });
    }

    // --------- VALIDATION ----------
    if (!Array.isArray(faceEmbedding) || faceEmbedding.length !== 128) {
      return res.status(400).json({
        success: false,
        message: `Valid 128-dimensional face embedding is required. Got ${faceEmbedding?.length || 0} dimensions.`
      });
    }

    // Validate all values are numbers
    const isValidEmbedding = faceEmbedding.every(val => typeof val === 'number' && !isNaN(val));
    if (!isValidEmbedding) {
      return res.status(400).json({
        success: false,
        message: 'Invalid face embedding: contains non-numeric values'
      });
    }

    if (!consentGiven) {
      return res.status(400).json({
        success: false,
        message: 'Consent must be given for face registration'
      });
    }

    if (!tenantId) {
      return res.status(400).json({
        success: false,
        message: 'Tenant ID is required'
      });
    }

    const { FaceData } = getModels(req);

    // Check if employee already registered
    const existingFace = await FaceData.findOne({
      tenant: tenantId,
      employee: userId,
      status: 'ACTIVE'
    });

    if (existingFace) {
      console.log('⚠️ Face already registered for employee:', userId);
      // Allow update - delete old registration
      await FaceData.deleteOne({ _id: existingFace._id });
      console.log('✅ Old face registration deleted for update');
    }

    // Mock quality & detection metrics
    const quality = { sharpness: 75, brightness: 120, contrast: 45, confidence: 92 };
    const detection = { bbox: { x: 50, y: 50, width: 200, height: 250 } };

    // --------- ENCRYPT EMBEDDING ----------
    const faceRecognitionService = FaceRecognitionService;
    let encryptedEmbedding;
    try {
      encryptedEmbedding = faceRecognitionService.encryptEmbedding(
        faceEmbedding,
        ENCRYPTION_KEY
      );
      console.log('📝 Registration Encryption Details:');
      console.log('   Employee ID:', userId);
      console.log('   Embedding Length:', faceEmbedding.length);
      console.log('   First 5 values:', faceEmbedding.slice(0, 5).map(v => v.toFixed(4)));
      console.log('   Encrypted Key Present:', !!encryptedEmbedding.encrypted);
      console.log('   IV Present:', !!encryptedEmbedding.iv);
      console.log('   AuthTag Present:', !!encryptedEmbedding.authTag);
      console.log('✅ Embedding encrypted successfully');
    } catch (encryptErr) {
      console.error('❌ Encryption failed:', encryptErr);
      return res.status(500).json({
        success: false,
        message: 'Failed to encrypt face data'
      });
    }

    // --------- CREATE FACE RECORD ----------
    const faceData = new FaceData({
      tenant: tenantId,
      employee: userId,
      faceEmbedding: encryptedEmbedding, // encrypted object with iv, encrypted, authTag
      quality,
      detection,
      registration: {
        registeredAt: new Date(),
        registeredBy: userId,
        registrationNotes: registrationNotes || `Registered by ${employeeName || 'Self'}`,
        deviceInfo: req.headers['user-agent'] || 'Unknown',
        ipAddress: req.headers['x-forwarded-for']?.split(',')[0] || req.connection?.remoteAddress || 'Unknown',
        consentVersion: 1,
        consentGiven: true,
        consentGivenAt: new Date()
      },
      status: 'ACTIVE',
      isVerified: true,
      verification: {
        verifiedAt: new Date(),
        verifiedBy: userId
      },
      liveness: { status: 'PASSED', confidence: 90, method: 'TEXTURE' },
      model: { name: 'facenet-mobilenet-v2', version: '1.0.0', generatedAt: new Date() }
    });

    await faceData.save();

    res.status(201).json({
      success: true,
      message: 'Face registered successfully',
      data: {
        faceDataId: faceData._id,
        employeeId: faceData.employee,
        registeredAt: faceData.registration.registeredAt
      }
    });

  } catch (err) {
    console.error('Face registration error:', err);
    res.status(500).json({
      success: false,
      message: 'Face registration failed',
      error: err.message
    });
  }
};

// 🔹 Verify Face (Mark Attendance with Face)
// exports.verifyFaceAttendance = async (req, res) => {
//     try {
//         const { faceImageData, location } = req.body;
//         const employeeId = req.user.id;
//         const tenantId = req.tenantId || req.body.tenantId;

//         if (!faceImageData) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'Face image data is required'
//             });
//         }

//         if (!location || !location.lat || !location.lng) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'Location data is required'
//             });
//         }

//         const { FaceData, Attendance, Employee } = getModels(req);

//         // Check if employee has registered face
//         const registeredFace = await FaceData.findOne({
//             tenant: tenantId,
//             employee: employeeId,
//             status: 'ACTIVE'
//         });

//         if (!registeredFace) {
//             return res.status(404).json({
//                 success: false,
//                 message: 'No registered face found. Please register your face first.'
//             });
//         }

//         // 🔍 FACE COMPARISON - Compare uploaded face with registered face
//         console.log('🔍 Comparing faces for employee:', employeeId);
//         try {
//             const crypto = require('crypto');

//             // Generate embedding from current face image
//             const imageBuffer = Buffer.from(faceImageData.split('base64,')[1] || faceImageData, 'base64');
//             const hash = crypto.createHash('sha256').update(imageBuffer).digest();

//             // Generate 128-dim embedding from live image
//             const liveEmbedding = new Array(128);
//             for (let i = 0; i < 128; i++) {
//               const byteIndex = (i * 2) % hash.length;
//               const nextByteIndex = (byteIndex + 1) % hash.length;
//               const value = (hash[byteIndex] + hash[nextByteIndex]) / 512 - 1;
//               liveEmbedding[i] = value;
//             }

//             console.log('✅ Live embedding generated, length:', liveEmbedding.length);

//             // Decrypt stored embedding for comparison
//             let storedEmbedding;
//             try {
//               const decryptionKey = crypto.randomBytes(32); // In production, use proper key management
//               const storedIv = Buffer.from(registeredFace.faceEmbedding.iv, 'hex');
//               const storedEncrypted = Buffer.from(registeredFace.faceEmbedding.encrypted, 'hex');
//               const storedAuthTag = Buffer.from(registeredFace.faceEmbedding.authTag, 'hex');

//               const decipher = crypto.createDecipheriv('aes-256-gcm', decryptionKey, storedIv);
//               decipher.setAuthTag(storedAuthTag);
//               const decrypted = Buffer.concat([decipher.update(storedEncrypted), decipher.final()]);
//               storedEmbedding = JSON.parse(decrypted.toString());
//             } catch (err) {
//               // If decryption fails, use a fallback
//               console.warn('⚠️ Could not decrypt stored embedding, using fallback comparison');
//               storedEmbedding = new Array(128).fill(0);
//             }

//             console.log('✅ Stored embedding retrieved, length:', storedEmbedding.length);

//             // Calculate similarity (Euclidean distance)
//             let sumSquares = 0;
//             for (let i = 0; i < 128; i++) {
//               const diff = liveEmbedding[i] - storedEmbedding[i];
//               sumSquares += diff * diff;
//             }
//             const distance = Math.sqrt(sumSquares);
//             const similarity = Math.max(0, 1 - (distance / 1.5));

//             console.log(`🔍 Euclidean Distance: ${distance.toFixed(4)}`);
//             console.log(`🔍 Similarity Score: ${similarity.toFixed(4)} (${(similarity * 100).toFixed(1)}%)`);

//             const MATCHING_THRESHOLD = 0.48;
//             const isMatch = similarity >= MATCHING_THRESHOLD;

//             console.log(`🔍 Threshold: ${MATCHING_THRESHOLD}`);
//             console.log(`🔍 Match Result: ${isMatch ? '✅ MATCH' : '❌ NO MATCH'}`);

//             if (!isMatch) {
//                 console.log('❌ Face verification failed - similarity too low');
//                 return res.status(400).json({
//                     success: false,
//                     message: 'Face verification failed',
//                     details: {
//                       similarity: Number(similarity.toFixed(4)),
//                       threshold: MATCHING_THRESHOLD,
//                       message: 'Your face does not match the registered template. Please try again.'
//                     }
//                 });
//             }
//             console.log('✅ Face verification succeeded - similarity above threshold');
//         } catch (faceComparisonError) {
//             console.error('❌ Face comparison error:', faceComparisonError.message);
//             return res.status(500).json({
//                 success: false,
//                 message: 'Error during face comparison',
//                 error: faceComparisonError.message
//             });
//         }

//         // Check location accuracy
//         const employee = await Employee.findOne({ _id: employeeId }).lean();

//         if (!employee) {
//             return res.status(404).json({
//                 success: false,
//                 message: 'Employee record not found'
//             });
//         }

//         if (location.accuracy > (employee.allowedAccuracy || 100)) {
//             return res.status(400).json({
//                 success: false,
//                 message: `Location accuracy too low. Required: ${employee.allowedAccuracy || 100}m, Got: ${location.accuracy}m`
//             });
//         }

//         // Check geofence (if applicable)
//         const demoGeofence = [
//             { "lat": 23.03010, "lng": 72.51790 },
//             { "lat": 23.03010, "lng": 72.51830 },
//             { "lat": 23.03040, "lng": 72.51830 },
//             { "lat": 23.03040, "lng": 72.51790 }
//         ];

//         if (employee.geofance && employee.geofance.length > 0) {
//             const inside = isInsidePolygon(location, employee.geofance);
//             if (!inside) {
//                 return res.status(400).json({
//                     success: false,
//                     message: 'You are outside the office location'
//                 });
//             }
//         }

//         // Check if attendance already marked
//         const now = new Date();
//         const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
//         today.setHours(0, 0, 0, 0);

//         let attendance = await Attendance.findOne({
//             employee: employeeId,
//             tenant: tenantId,
//             date: today
//         });

//         if (attendance && attendance.checkIn) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'Attendance already marked for today',
//                 data: { checkInTime: attendance.checkIn }
//             });
//         }

//         // Create or update attendance
//         if (!attendance) {
//             attendance = new Attendance({
//                 tenant: tenantId,
//                 employee: employeeId,
//                 date: today,
//                 checkIn: now,
//                 status: 'present',
//                 logs: []
//             });
//         }

//         attendance.logs.push({
//             time: now,
//             type: 'IN',
//             location: `${location.lat}, ${location.lng}`,
//             device: 'Face Recognition',
//             ip: req.headers['x-forwarded-for']?.split(',')[0] || req.connection?.remoteAddress
//         });

//         await attendance.save();

//         // Update face data usage
//         await FaceData.updateOne(
//             { _id: registeredFace._id },
//             {
//                 $set: { lastUsedAt: now },
//                 $inc: { usageCount: 1 }
//             }
//         );

//         res.json({
//             success: true,
//             message: 'Attendance marked successfully via face recognition',
//             data: {
//                 attendanceId: attendance._id,
//                 checkInTime: attendance.checkIn,
//                 employee: {
//                     id: employee._id,
//                     name: `${employee.firstName} ${employee.lastName}`,
//                     role: employee.role
//                 },
//                 location: {
//                     latitude: location.lat,
//                     longitude: location.lng,
//                     accuracy: location.accuracy
//                 }
//             }
//         });

//     } catch (err) {
//         console.error('Face verification error:', err);
//         res.status(500).json({
//             success: false,
//             message: 'Face verification failed',
//             error: err.message
//         });
//     }
// };


// ====== HELPERS ======
function decryptEmbedding(encrypted) {
    const iv = Buffer.from(encrypted.iv, 'hex');
    const data = Buffer.from(encrypted.data, 'hex');
    const tag = Buffer.from(encrypted.tag, 'hex');

    const decipher = crypto.createDecipheriv('aes-256-gcm',  MASTER_FACE_KEY, iv);
    decipher.setAuthTag(tag);

    const decrypted = Buffer.concat([
        decipher.update(data),
        decipher.final()
    ]);

    return JSON.parse(decrypted.toString());
}

function cosineSimilarity(a, b) {
    // Validate inputs
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) {
        console.error('❌ COSINE SIMILARITY ERROR: Invalid input arrays');
        return -1; // Return invalid value to trigger rejection
    }

    let dot = 0, normA = 0, normB = 0;

    for (let i = 0; i < a.length; i++) {
        if (typeof a[i] !== 'number' || typeof b[i] !== 'number') {
            console.error(`❌ COSINE SIMILARITY ERROR: Non-numeric value at index ${i}`);
            return -1;
        }
        dot += a[i] * b[i];
        normA += a[i] * a[i];
        normB += b[i] * b[i];
    }

    const sqrtNormA = Math.sqrt(normA);
    const sqrtNormB = Math.sqrt(normB);

    // Check for division by zero
    if (sqrtNormA === 0 || sqrtNormB === 0) {
        console.error('❌ COSINE SIMILARITY ERROR: Zero-magnitude vector detected');
        return -1;
    }

    const similarity = dot / (sqrtNormA * sqrtNormB);

    // Validate result is in valid range [-1, 1]
    if (similarity < -1.1 || similarity > 1.1) {
        console.error('❌ COSINE SIMILARITY ERROR: Result out of valid range:', similarity);
        return -1;
    }

    return similarity;
}

function isValidLocation(location) {
    return (
        location &&
        typeof location.lat === 'number' &&
        typeof location.lng === 'number'
    );
}

// ====== CONTROLLER ======
// exports.verifyFaceAttendance = async (req, res) => {
//     try {

//         console.log('REQ BODY:', req.body);
//         console.log('faceImageData exists:', Array.isArray(req.body.faceImageData));
//         console.log('faceImageData length:', req.body.faceImageData?.length);

//         const { faceImageData, location } = req.body;
//         const employeeId = req.user.id;
//         const tenantId = req.tenantId;

//         // ---------- BASIC VALIDATION ----------
//         if (!Array.isArray(faceImageData) || faceImageData.length < 128) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'Valid face embedding is required is not array'
//             });
//         }

//         if (!isValidLocation(location)) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'Valid location data is required there is not valid location'
//             });
//         }

//         const { FaceData, Attendance, Employee } = getModels(req);

//         // ---------- FETCH REGISTERED FACE ----------
//         const registeredFace = await FaceData.findOne({
//             tenant: tenantId,
//             employee: employeeId,
//             status: 'ACTIVE'
//         });

//         if (!registeredFace) {
//             return res.status(404).json({
//                 success: false,
//                 message: 'Face not registered'
//             });
//         }

//         // ---------- DECRYPT STORED EMBEDDING ----------
//         let storedEmbedding;
//         try {
//             storedEmbedding = decryptEmbedding(registeredFace.faceEmbedding);
//         } catch (err) {
//             console.error('Embedding decryption failed:', err);
//             return res.status(500).json({
//                 success: false,
//                 message: 'Face data corrupted. Please re-register face.'
//             });
//         }

//         // ---------- FACE MATCH ----------
//         const similarity = cosineSimilarity(faceEmbedding, storedEmbedding);

//         if (similarity < FACE_MATCH_THRESHOLD) {
//             return res.status(403).json({
//                 success: false,
//                 message: 'Face verification failed',
//                 details: {
//                     similarity: Number(similarity.toFixed(4)),
//                     threshold: FACE_MATCH_THRESHOLD
//                 }
//             });
//         }

//         // ---------- EMPLOYEE ----------
//         const employee = await Employee.findById(employeeId).lean();
//         if (!employee) {
//             return res.status(404).json({
//                 success: false,
//                 message: 'Employee not found'
//             });
//         }

//         // ---------- LOCATION ACCURACY ----------
//         const allowedAccuracy = employee.allowedAccuracy || 100;
//         if (location.accuracy && location.accuracy > allowedAccuracy) {
//             return res.status(400).json({
//                 success: false,
//                 message: `Location accuracy too low (${location.accuracy}m)`
//             });
//         }

//         // ---------- ATTENDANCE ----------
//         const now = new Date();
//         const today = new Date(now.setHours(0, 0, 0, 0));

//         let attendance = await Attendance.findOne({
//             employee: employeeId,
//             tenant: tenantId,
//             date: today
//         });

//         if (attendance?.checkIn) {
//             return res.status(400).json({
//                 success: false,
//                 message: 'Attendance already marked'
//             });
//         }

//         if (!attendance) {
//             attendance = new Attendance({
//                 tenant: tenantId,
//                 employee: employeeId,
//                 date: today,
//                 status: 'present',
//                 logs: []
//             });
//         }

//         attendance.checkIn = new Date();
//         attendance.logs.push({
//             time: new Date(),
//             type: 'IN',
//             location: `${location.lat}, ${location.lng}`,
//             device: 'Face Recognition',
//             ip: req.headers['x-forwarded-for'] || req.socket.remoteAddress
//         });

//         await attendance.save();

//         // ---------- UPDATE FACE USAGE ----------
//         await FaceData.updateOne(
//             { _id: registeredFace._id },
//             {
//                 $inc: { usageCount: 1 },
//                 $set: { lastUsedAt: new Date() }
//             }
//         );

//         // ---------- SUCCESS ----------
//         res.json({
//             success: true,
//             message: 'Attendance marked successfully',
//             data: {
//                 attendanceId: attendance._id,
//                 checkInTime: attendance.checkIn,
//                 similarity: Number(similarity.toFixed(4))
//             }
//         });

//     } catch (err) {
//         console.error('Face attendance error:', err);
//         res.status(500).json({
//             success: false,
//             message: 'Internal server error'
//         });
//     }
// };


// Location validation helper
function isValidLocation(loc) {
  return loc && typeof loc.lat === 'number' && typeof loc.lng === 'number';
}

exports.verifyFaceAttendance = async (req, res) => {
  try {
    const { faceEmbedding, location } = req.body;
    const employeeId = req.user.id;
    const tenantId = req.tenantId;

    // ---------- VALIDATION ----------
    if (!Array.isArray(faceEmbedding) || faceEmbedding.length !== 128) {
      return res.status(400).json({
        success: false,
        message: `Valid 128-dimensional face embedding is required. Got ${faceEmbedding?.length || 0}.`
      });
    }

    // Validate all values are numbers
    const isValidEmbedding = faceEmbedding.every(val => typeof val === 'number' && !isNaN(val));
    if (!isValidEmbedding) {
      return res.status(400).json({
        success: false,
        message: 'Invalid embedding: contains non-numeric values'
      });
    }

    if (!isValidLocation(location)) {
      return res.status(400).json({
        success: false,
        message: 'Valid location data is required'
      });
    }

    const { FaceData, Attendance, Employee } = getModels(req);

    // ---------- FETCH REGISTERED FACE ----------
    const registeredFace = await FaceData.findOne({
      tenant: tenantId,
      employee: employeeId,
      status: 'ACTIVE'
    });

    if (!registeredFace) {
      console.log('❌ FACE REJECTED - No registered face found for employee:', employeeId);
      return res.status(404).json({
        success: false,
        message: 'Face not registered for this employee. Please register first.'
      });
    }

    // Verify face belongs to current employee
    if (registeredFace.employee.toString() !== employeeId.toString()) {
      console.log('❌ FACE REJECTED - Face does not belong to current employee');
      console.log('   Registered to:', registeredFace.employee.toString());
      console.log('   Current user:', employeeId.toString());
      return res.status(403).json({
        success: false,
        message: 'Face does not belong to your account. Access denied.',
        status: 'REJECTED'
      });
    }

    // ---------- DECRYPT STORED EMBEDDING ----------
    const faceRecognitionService = FaceRecognitionService;
    let storedEmbedding;
    
    try {
      storedEmbedding = faceRecognitionService.decryptEmbedding(
        registeredFace.faceEmbedding,
        ENCRYPTION_KEY
      );
      console.log('✅ Embedding decrypted successfully for comparison');
    } catch (err) {
      console.error('❌ Failed to decrypt stored embedding:', err);
      return res.status(500).json({
        success: false,
        message: 'Failed to verify face - decryption error'
      });
    }

    // Ensure decrypted is an array
    if (!Array.isArray(storedEmbedding)) {
      console.error('❌ Decrypted embedding is not an array:', typeof storedEmbedding);
      return res.status(500).json({
        success: false,
        message: 'Invalid stored embedding format'
      });
    }

    // Validate decrypted embedding is properly formed
    if (storedEmbedding.length !== 128) {
      console.error('❌ Decrypted embedding has wrong dimension:', storedEmbedding.length);
      return res.status(500).json({
        success: false,
        message: 'Invalid stored embedding dimensions'
      });
    }

    const isValidDecryptedEmbedding = storedEmbedding.every(val => typeof val === 'number' && !isNaN(val));
    if (!isValidDecryptedEmbedding) {
      console.error('❌ Decrypted embedding contains invalid values');
      return res.status(500).json({
        success: false,
        message: 'Invalid stored embedding values'
      });
    }

    // ---------- FACE MATCH - EXTREMELY STRICT VALIDATION ----------
    const similarity = cosineSimilarity(faceEmbedding, storedEmbedding);
    
    console.log('\n' + '='.repeat(80));
    console.log('🔍 CRITICAL: FACE MATCHING VALIDATION');
    console.log('='.repeat(80));
    console.log('Employee ID:', employeeId);
    console.log('Tenant ID:', tenantId);
    console.log('');
    console.log('INCOMING EMBEDDING:');
    console.log('  - Length:', faceEmbedding.length);
    console.log('  - First 10 values:', faceEmbedding.slice(0, 10).map(v => parseFloat(v.toFixed(6))));
    console.log('  - Sum:', faceEmbedding.reduce((a, b) => a + b, 0).toFixed(4));
    console.log('  - Mean:', (faceEmbedding.reduce((a, b) => a + b, 0) / faceEmbedding.length).toFixed(4));
    console.log('');
    console.log('STORED EMBEDDING:');
    console.log('  - Length:', storedEmbedding.length);
    console.log('  - First 10 values:', storedEmbedding.slice(0, 10).map(v => parseFloat(v.toFixed(6))));
    console.log('  - Sum:', storedEmbedding.reduce((a, b) => a + b, 0).toFixed(4));
    console.log('  - Mean:', (storedEmbedding.reduce((a, b) => a + b, 0) / storedEmbedding.length).toFixed(4));
    console.log('');
    console.log('SIMILARITY SCORE:');
    console.log('  - Cosine Similarity:', similarity);
    console.log('  - Similarity (formatted):', similarity.toFixed(6));
    console.log('  - Is Valid Number?:', !isNaN(similarity) && isFinite(similarity));
    console.log('');
    console.log('THRESHOLD CHECK:');
    console.log('  - Minimum Threshold:', FACE_MATCH_THRESHOLD);
    console.log('  - Similarity >= Threshold?:', similarity >= FACE_MATCH_THRESHOLD);
    console.log('  - Difference from Threshold:', (similarity - FACE_MATCH_THRESHOLD).toFixed(6));
    console.log('='.repeat(80) + '\n');

    // CRITICAL CHECK 1: Similarity must be a valid number
    if (!isFinite(similarity)) {
      console.log('❌ CRITICAL REJECTION - Similarity is not a valid number:', similarity);
      return res.status(500).json({
        success: false,
        message: 'Face comparison failed - invalid similarity calculation',
        status: 'REJECTED'
      });
    }

    // CRITICAL CHECK 2: Similarity must be ABOVE threshold to match
    if (similarity < FACE_MATCH_THRESHOLD) {
      console.log('❌ FACE REJECTED - SIMILARITY TOO LOW');
      console.log('   Incoming face does NOT match registered face');
      console.log('   Similarity:', similarity.toFixed(6), '< Threshold:', FACE_MATCH_THRESHOLD);
      return res.status(403).json({
        success: false,
        message: 'Face verification FAILED. This face does not match your registered face. Access DENIED.',
        details: { 
          similarity: Number(similarity.toFixed(6)), 
          threshold: FACE_MATCH_THRESHOLD,
          status: 'REJECTED',
          reason: 'Face mismatch'
        }
      });
    }

    // CRITICAL CHECK 3: Embeddings must be reasonably different (not identical)
    const embeddingDifference = faceEmbedding.reduce((sum, val, i) => sum + Math.abs(val - storedEmbedding[i]), 0);
    console.log('Embedding Difference (L1 distance):', embeddingDifference.toFixed(6));
    
    if (embeddingDifference < 0.001) {
      console.log('⚠️  WARNING: Embeddings are TOO SIMILAR (possible data corruption)');
      // Allow but warn
    }

    // CRITICAL CHECK 4: Additional spoofing detection
    if (similarity > 0.99) {
      console.log('⚠️  SUSPICIOUS: Similarity suspiciously high (possible fake/duplicate)');
      // Still allow if threshold passed, but log warning
    }

    console.log('✅ FACE APPROVED - Similarity matches registered face, access GRANTED');

    // ---------- EMPLOYEE ----------
    const employee = await Employee.findById(employeeId).lean();
    if (!employee) {
      return res.status(404).json({ success: false, message: 'Employee not found' });
    }

    // ---------- LOCATION ACCURACY ----------
    const allowedAccuracy = employee.allowedAccuracy || 100;
    if (location.accuracy && location.accuracy > allowedAccuracy) {
      return res.status(400).json({
        success: false,
        message: `Location accuracy too low (${location.accuracy}m)`
      });
    }

    // ---------- ATTENDANCE ----------
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let attendance = await Attendance.findOne({
      employee: employeeId,
      tenant: tenantId,
      date: today
    });

    if (attendance?.checkIn) {
      return res.status(400).json({ success: false, message: 'Attendance already marked' });
    }

    if (!attendance) {
      attendance = new Attendance({
        tenant: tenantId,
        employee: employeeId,
        date: today,
        status: 'present',
        logs: []
      });
    }

    attendance.checkIn = new Date();
    attendance.logs.push({
      time: new Date(),
      type: 'IN',
      location: `${location.lat},${location.lng}`,
      device: 'Face Recognition',
      ip: req.headers['x-forwarded-for'] || req.socket.remoteAddress
    });

    await attendance.save();

    // ---------- UPDATE FACE USAGE ----------
    await FaceData.updateOne(
      { _id: registeredFace._id },
      { $inc: { usageCount: 1 }, $set: { lastUsedAt: new Date() } }
    );

    // ---------- SUCCESS ----------
    res.json({
      success: true,
      message: 'Attendance marked successfully',
      data: { attendanceId: attendance._id, checkInTime: attendance.checkIn, similarity: Number(similarity.toFixed(4)) }
    });

  } catch (err) {
    console.error('Face attendance error:', err);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

// 🔹 Get Face Registration Status
exports.getFaceStatus = async (req, res) => {
    try {
        const employeeId = req.user?.id || req.body.employeeId;
        const tenantId = req.tenantId;

        if (!employeeId || !tenantId) {
            return res.status(400).json({
                success: false,
                message: 'Employee ID and Tenant ID required'
            });
        }

        const { FaceData } = getModels(req);

        const faceData = await FaceData.findOne({
            tenant: tenantId,
            employee: employeeId,
            status: 'ACTIVE'
        }).select('-faceImageData -faceDescriptor -faceEmbedding');

        if (!faceData) {
            return res.json({
                success: true,
                isRegistered: false,
                message: 'Face not registered. Please register your face first.'
            });
        }

        res.json({
            success: true,
            isRegistered: true,
            data: {
                registeredAt: faceData.registration?.registeredAt,
                isVerified: faceData.isVerified,
                usageCount: faceData.usageCount || 0,
                lastUsedAt: faceData.lastUsedAt,
                quality: faceData.quality
            }
        });
    } catch (err) {
        console.error('Face status check error:', err);
        res.status(500).json({
            success: false,
            message: 'Failed to check face status'
        });
    }
};

// 🔹 Delete Face Registration
exports.deleteFace = async (req, res) => {
    try {
        const employeeId = req.user.id;
        const tenantId = req.tenantId;

        const { FaceData } = getModels(req);

        const result = await FaceData.updateOne(
            {
                tenant: tenantId,
                employee: employeeId
            },
            {
                $set: { status: 'inactive' }
            }
        );

        if (result.matchedCount === 0) {
            return res.status(404).json({
                success: false,
                message: 'Face registration not found'
            });
        }

        res.json({
            success: true,
            message: 'Face registration deleted successfully'
        });

    } catch (err) {
        console.error('Delete face error:', err);
        res.status(500).json({
            success: false,
            message: 'Failed to delete face registration',
            error: err.message
        });
    }
};